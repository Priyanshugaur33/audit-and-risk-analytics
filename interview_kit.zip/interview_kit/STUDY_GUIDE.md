# Priyanshu's 3-Day Interview Rescue Guide
Projects covered: (1) AI-Powered Engineering Audit & Risk Analytics Platform, (2) Portfolio Analytics & Demand Forecasting (E-commerce).

> **Honest note first.** Your original code and data are gone, so this kit is a *rebuild*: I recreated both projects as runnable code on synthetic data that matches your resume (20,000+ transactions, 15+ features, 10+ SQL/Python tests, 12+ KPIs; 15,000+ rows, 5+ categories, 4 regions, ~90% accuracy, 15+ KPIs). Numbers quoted below come from *my* rebuild runs. In the interview, use the figures from your resume, explain the *method*, and never invent details you do not know. "I'd have to check the exact number, but the approach was..." is a perfectly good answer. Run the code yourself at least once so you can say "I built and ran this."

---------------------------------------------------------------------------------------------------

## 0. The 3-day plan (about 4-5 hours per day)

**Day 1 (tonight/tomorrow): Understand.** Read sections 1-3. Run Project 1 (`python generate_data.py` then `python run_pipeline.py`). Read each SQL test aloud and say what it catches.
**Day 2: Own it.** Read sections 4-5. Run Project 2. Change one thing in each project (e.g. contamination 3% -> 5%, add a SQL test, try another model) and see what changes. Practise both 60-second pitches aloud.
**Day 3: Drill.** Section 6 Q&A aloud, 2 rounds. Section 7 (rest of resume). Section 8 (questions to ask them). Sleep well.

---------------------------------------------------------------------------------------------------

## 1. Banking and audit concepts (the vocabulary you must own)

| Term | Plain meaning |
|---|---|
| **Internal audit** | Independent check that a bank's processes and controls work as designed. |
| **Control** | A rule that prevents errors/fraud (e.g. two people must approve a big payment). |
| **Control exception** | A transaction that broke a control. |
| **Maker-checker (segregation of duties)** | The person who initiates a transaction must not be the one who approves it. |
| **Structuring / smurfing** | Splitting or sizing amounts just under a reporting threshold (e.g. just under 1,00,000) to avoid detection. Relevant to AML (anti-money laundering). |
| **AML / KYC** | Anti-Money Laundering / Know Your Customer. |
| **Population testing vs sampling** | Traditional audit samples ~50 items. Analytics tests 100% of records. That is the selling point of your project. |
| **Continuous auditing/monitoring** | Automated tests run regularly, not once a year. |
| **Risk-based prioritisation** | Auditors have limited time, so rank cases by risk and review the highest first. |
| **False positive / false negative** | Flagging a clean txn / missing a bad one. In audit, missing bad ones is costlier, but too many false positives wastes reviewer time. |
| **Credit risk / operational risk / fraud risk** | Borrower default / process or people failure / deliberate deception. Your project mostly touches operational and fraud risk. |
| **KPI vs KRI** | Performance indicator vs risk indicator (e.g. exception rate is a KRI). |

---------------------------------------------------------------------------------------------------

## 2. PROJECT 1: AI-Powered Engineering Audit & Risk Analytics Platform

### 2.1 One-line pitch
"I built an analytics platform that tests 100% of 20,000+ banking transactions with automated SQL and Python audit tests, adds ML anomaly detection, and ranks cases by a risk score so auditors review the riskiest first, all shown in a Power BI dashboard."

### 2.2 Problem and why it matters
Manual audit samples a tiny slice of transactions, so exceptions slip through. Automating rule tests plus ML covers the whole population and prioritises review effort.

### 2.3 Pipeline (draw this on paper and memorise it)
```
Raw transactions (CSV/SQL)
   -> Data-quality validation (nulls, negatives, duplicates)
   -> 10 SQL audit tests (rule-based exceptions)
   -> Feature engineering (16 features)
   -> Isolation Forest (unsupervised anomaly score)
   -> Risk score = 60% ML anomaly + 40% rule hits  -> Low / Medium / High / Critical
   -> Exports -> Power BI dashboard (KPIs, trends, remediation status)
```

### 2.4 The data (columns)
txn_id, txn_datetime, customer_id, branch_id, channel (ATM/Online/Branch/POS/Mobile), txn_type, amount, country, approved_by, initiated_by, account_balance_after.

### 2.5 The 10 audit tests (know what each catches and why an auditor cares)
| Test | Logic | Why it matters |
|---|---|---|
| T01 Missing fields | NULL branch/channel/amount | Data completeness, weak input controls |
| T02 Non-positive amount | amount <= 0 | Invalid data / possible reversal abuse |
| T03 Duplicates | same customer+amount+type within 10 min | Double posting, duplicate payment |
| T04 Maker-checker | approver = initiator (not SYSTEM) | Segregation-of-duties breach, fraud risk |
| T05 Large transactions | amount >= 3,00,000 | High-value items need scrutiny |
| T06 Structuring | amount between 95,000 and 99,999 | Sizing under a 1,00,000 reporting threshold |
| T07 Off-hours large | 12am-5am and >= 50,000 | Unusual timing, possible unauthorised activity |
| T08 Foreign high value | non-IN country and >= 1,00,000 | Cross-border risk |
| T09 Velocity | >3 txns by a customer in one day | Rapid-fire activity, account takeover |
| T10 Monthly trend | counts and value by month | Trend monitoring |

**SQL concepts used (be ready to explain):** `JOIN` (self-join for duplicates), `GROUP BY ... HAVING`, `CASE`/`BETWEEN`, date functions, `COUNT`, `ABS`, window functions as an extension.

### 2.6 The 16 engineered features (say "15+")
hour, dayofweek, is_weekend, is_offhours, log_amount, customer z-score of amount, customer txn count, txns per customer per day, near_threshold flag, is_foreign, same_approver flag, amount-to-balance ratio, branch percentile of amount, channel code, customer std, customer mean.
**Why features matter:** a 2,00,000 transfer is normal for one customer and wildly abnormal for another. The *customer z-score* captures "unusual for THIS customer."

### 2.7 Isolation Forest, explained simply (very likely interview topic)
- Unsupervised: no fraud labels needed (real banks rarely have clean labels).
- Idea: build many random trees that split data randomly. **Anomalies are rare and different, so they get isolated in fewer splits.** Short average path = more anomalous.
- Output: anomaly score. `contamination=0.03` means "expect ~3% anomalies" and sets the cut-off.
- Strengths: fast, handles many features, no labels. Weaknesses: contamination is a guess, hard to explain *why* a row was flagged, flags "unusual" not necessarily "fraudulent".
- Why scale features first: keeps scale from dominating, standard hygiene (trees are less sensitive, but it is good practice).
- Why combine with rules: rules are explainable and defensible to auditors; ML finds patterns rules miss. Together = better coverage.

### 2.8 Risk score
`risk_score = 100 x (0.6 x normalised ML anomaly score + 0.4 x min(rule_hits/3, 1))`
Bands: Low (<=30), Medium (30-50), High (50-65), Critical (>65). Weights are a judgement call, and you can say you would calibrate them with auditor feedback.

### 2.9 Results from my rebuild (illustrative)
- 20,050 rows loaded; 110 missing-field rows, 40 non-positive, 50 duplicates, 100 maker-checker, 120 large, 103 near-threshold, 147 off-hours large, 10 foreign high-value.
- About 2.5% of transactions have >=1 rule exception; ML flags ~3%; the two overlap substantially (324 shared), which shows they complement each other.
- Risk mix: ~94% Low, ~4% Medium, ~1% High, ~0.5% Critical. So auditors review about 300 cases instead of 20,000.

### 2.10 Power BI dashboard (12+ KPIs)
Total transactions, total value, exception rate, ML anomaly rate, critical cases, high cases, audit coverage (100%), risk distribution, exceptions by test, exceptions by branch, monthly trend, remediation status (Open / In Progress / Closed), top-risk cases table, channel risk split. Slicers: branch, channel, month, risk class.
**Know:** measure vs calculated column, DAX basics (`SUM`, `CALCULATE`, `DIVIDE`, `DISTINCTCOUNT`), star schema idea, drill-down.

### 2.11 Limitations (volunteer these, it shows maturity)
- No ground-truth labels, so precision/recall cannot be measured directly; you validated by checking that ML flags overlap with rule exceptions and by reviewing top cases.
- Contamination rate and weights are assumptions.
- Isolation Forest gives little explanation, so add SHAP or per-feature deviations.
- Next steps: label feedback loop from auditors, supervised model once labels exist, scheduled runs, alerting.

---------------------------------------------------------------------------------------------------

## 3. How to describe the Project 1 *story* (STAR)
- **Situation:** Audits rely on small samples, so control failures can be missed.
- **Task:** Build an automated, population-wide audit analytics workflow.
- **Action:** SQL/Python tests for data quality and control exceptions, 15+ features, Isolation Forest, a combined risk score, Power BI dashboard with alerts.
- **Result:** 100% coverage, a ranked shortlist of high-risk cases for review, and repeatable monitoring.

---------------------------------------------------------------------------------------------------

## 4. PROJECT 2: Portfolio Analytics & Demand Forecasting (E-commerce)

### 4.1 One-line pitch
"I built an end-to-end pipeline (ETL, EDA, modelling, reporting) on 15,000+ e-commerce rows across 5+ categories and 4 regions, cleaned the data, built a regression demand-forecasting model at roughly 90% accuracy, and delivered a 4-page Power BI dashboard tracking 15+ KPIs."

### 4.2 Pipeline
```
Raw sales data (messy)
  -> ETL / cleaning: remove duplicates, impute missing values, cap outliers
  -> EDA: revenue by category/region, monthly trend, discount and promo effects
  -> Model: regression to predict units sold (features: category, region, price, discount, promo, month)
  -> Evaluation: R2, MAE, MAPE on a held-out 20% test set
  -> Power BI: 4 pages, 15+ KPIs
```

### 4.3 Cleaning (be precise, this is where interviewers probe)
| Problem | Fix | Why |
|---|---|---|
| Duplicates | `drop_duplicates()` | Avoid double counting revenue |
| Missing categorical (region) | mode | Preserves distribution |
| Missing numeric (price, discount) | **median within category** | Robust to outliers; category-aware |
| Missing flag (promo) | 0 | Missing most plausibly means no promo (state as an assumption) |
| Outliers in units | cap at Q3 + 3xIQR per category (winsorise) | Keeps rows, limits distortion |

Why median not mean: outliers pull the mean. Why not delete rows: you lose data, and with about 12% missing you could lose too much.

### 4.4 EDA findings (rebuild)
- Electronics is the top revenue category, West the top region.
- Q4 (Oct-Dec) has a clear seasonal uplift; discounts and promos raise units.
- Average discount about 8.6%, promo share about 24%.

### 4.5 Modelling
- Target: units_sold. Features: one-hot category/region, unit_price, discount_pct, promo_flag, month (plus month dummies).
- Models: Linear Regression (baseline, interpretable) vs Random Forest (non-linear).
- Rebuild results: R2 about 0.71, MAE about 7.5 units, **MAPE about 10% -> "about 90% accuracy"** (accuracy defined as 100 - MAPE). **Say how you define accuracy**, because "accuracy" is not a regression metric, and a sharp interviewer will ask.
- Top drivers: month (seasonality), category, price, discount.
- Metrics: **R2** = share of variance explained; **MAE** = average absolute error in units; **MAPE** = average percentage error (breaks when actuals are near 0).
- Train/test split 80/20, `random_state` for reproducibility.

### 4.6 Limitations / improvements
- Random split ignores time order. A proper forecast uses a **time-based split** or walk-forward validation.
- Add lag features, rolling averages, holidays; try gradient boosting or SARIMA/Prophet.
- Quantify uncertainty with prediction intervals.

### 4.7 Dashboard (4 pages, 15+ KPIs)
1. Executive summary (revenue, units, AOV, growth, top category/region)
2. Category and region performance
3. Discount and promo analysis
4. Forecast vs actual, error metrics
KPIs: total revenue, units, AOV, average discount, promo share, revenue by category/region, MoM growth, forecast accuracy, MAPE, top-N categories, etc.

---------------------------------------------------------------------------------------------------

## 5. Core concepts cheat-sheet (quick answers)
- **Overfitting:** model memorises training data; fix with a test set, regularisation, simpler model, more data.
- **Bias-variance:** simple model = high bias, complex = high variance.
- **Precision / recall:** precision = of flagged, how many truly bad; recall = of truly bad, how many flagged.
- **Standardisation vs normalisation:** z-score vs min-max scaling.
- **Hypothesis testing:** null vs alternative, p-value = probability of data this extreme if null is true; p < 0.05 conventionally rejects the null. Type I = false positive, Type II = false negative.
- **Correlation vs causation.**
- **ETL:** Extract, Transform, Load.
- **SQL joins:** INNER (matches only), LEFT (all left + matches), self-join (table joined to itself).
- **WHERE vs HAVING:** WHERE filters rows before grouping, HAVING filters groups after.
- **DBMS basics:** primary/foreign key, normalisation, indexes, ACID.
- **Pandas:** `groupby`, `merge`, `pivot_table`, `fillna`, `transform`, `apply`.

---------------------------------------------------------------------------------------------------

## 6. Interview Q&A (practise aloud)

**Project 1**
1. *Walk me through the project.* -> Use the pitch + pipeline + STAR.
2. *Why Isolation Forest?* -> Unsupervised (no labels), fast, works on tabular mixed features, isolates rare points in fewer splits.
3. *How did you validate without labels?* -> Compared against rule-based exceptions (overlap), reviewed top-ranked cases, sanity-checked flagged patterns; I would add auditor feedback as labels next.
4. *How is the risk score built?* -> Weighted blend of normalised ML score and rule hits; weights are tunable judgement.
5. *What is maker-checker?* -> Initiator and approver must be different people.
6. *What is structuring?* -> Keeping amounts just under a reporting threshold.
7. *Give an example SQL test.* -> Duplicates self-join or velocity `GROUP BY ... HAVING COUNT(*) > 3`.
8. *What if the model flags too many cases?* -> Lower contamination, raise the score threshold, add rule-based confirmation, tune with reviewer feedback.
9. *False positives vs false negatives here?* -> Missing a real fraud is costlier, but too many alerts cause alert fatigue; the risk bands balance this.
10. *What features mattered?* -> Customer-relative amount z-score, off-hours, near-threshold, amount-to-balance.
11. *How would you productionise it?* -> Scheduled pipeline (Airflow/cron), data validation, model monitoring, versioned outputs, alerting to dashboards.
12. *What would you improve?* -> Labels, explainability (SHAP), threshold calibration, streaming checks.
13. *How is this relevant to banking?* -> Internal audit, fraud, AML monitoring, regulatory reporting, risk-based audit planning.

**Project 2**
14. *Walk me through it.* -> Pitch + pipeline.
15. *How did you handle missing values?* -> Table in 4.3.
16. *How did you get 90% accuracy?* -> Define: 100 - MAPE on a held-out test set, about 10% average error.
17. *Why regression? Why not time-series models?* -> Demand depended on price/discount/promo/category/season, so feature-based regression fit; a time-series model (SARIMA/Prophet) is the next step.
18. *Is a random train/test split OK for forecasting?* -> Not ideal; a time-based split avoids leakage. I would change this.
19. *R2 vs MAE vs MAPE?* -> Section 4.5.
20. *How do discounts affect demand?* -> Higher discounts and promos lift units; quantify with feature importance or coefficients.
21. *What does your dashboard show a manager?* -> Section 4.7.

**General / HR / finance**
22. *You're mechanical, why finance/analytics?* -> Quantitative training, built end-to-end analytics projects, and risk/analysis work excites me; mechanical background gives structured problem-solving and a quality-control mindset (FIBA/CNC exposure).
23. *Strengths/weakness.* -> Be real, e.g. strong at structuring problems; working on deeper domain knowledge of banking regulation.
24. *Tell me about a challenge.* -> Cleaning messy data, or learning anomaly detection with no labels.
25. *Tell me about teamwork.* -> Quiz Club (100+ attendees) and SPHINX marketing, coordinating teams and partners.
26. *Where do you see yourself in 5 years?* -> Growing into a risk/data analytics specialist in banking.
27. *What is NPA? What is repo rate? What is CRR/SLR?* -> NPA = loan unpaid 90+ days. Repo = rate at which RBI lends to banks. CRR = share of deposits banks keep with RBI; SLR = share kept in liquid assets. (Read quick current-affairs on RBI before the interview.)
28. *What is credit analysis?* -> Assessing a borrower's ability to repay (cash flow, ratios like DSCR, collateral, history).
29. *What if you do not know the answer?* -> Say so, then reason step by step. That is fine.

**If they ask "Where is your GitHub?"** Be straightforward: you lost access to the repositories and have rebuilt the projects locally to prepare. Do not claim it is still online. Offer to walk through the code live.

---------------------------------------------------------------------------------------------------

## 7. Rest of your resume (they can ask about anything on it)
- **North Western Railway internship:** be able to explain FIBA (a train safety device related to fibre-optic/wheel-defect detection) in your own words and what you actually did. Only say what you truly worked on.
- **Deloitte Australia job simulation (Forage):** data analytics tasks such as data analysis, visualisation, and drawing insights. Recall what tasks you did.
- **Skills section:** only be ready to discuss what you can defend. If R or Tableau are weak, expect a basic question and answer honestly.
- **Positions of responsibility:** one specific story each, with your role and outcome.

## 8. Questions to ask them
- "What does the analyst team's day-to-day look like in the first six months?"
- "Which data tools/stack does the team use?"
- "How is success measured for this role?"

---------------------------------------------------------------------------------------------------

## 9. Last-night checklist
- [ ] Both pitches under 60 seconds, said aloud
- [ ] Both pipelines drawn from memory
- [ ] Isolation Forest explained in 30 seconds
- [ ] Missing-value strategy explained
- [ ] Definition of "accuracy" ready
- [ ] 3 SQL queries writeable from scratch (duplicates, GROUP BY HAVING, join)
- [ ] One failure/learning story
- [ ] Questions for the interviewer
