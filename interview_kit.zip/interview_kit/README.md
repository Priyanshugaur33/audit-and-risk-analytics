# Interview Kit (rebuilt repo)

Start with `STUDY_GUIDE.md`.

```
pip install pandas numpy scikit-learn matplotlib
cd project1_audit_risk
python generate_data.py      # creates data/transactions.csv (synthetic, 20,050 rows)
python run_pipeline.py       # SQL tests -> features -> Isolation Forest -> risk score -> outputs/
cd ../project2_demand_forecasting
python run_pipeline.py       # generates, cleans, models, exports to outputs/
```

Power BI: load the CSVs in each `outputs/` folder (Get Data > Text/CSV) and build the visuals described in the guide.
Data is synthetic (your originals were lost); methods and structure follow your resume.
